import { spawn } from "child_process";
import path from "path";
import fs from "fs";
import { db } from "@workspace/db";
import { downloadJobsTable, songsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { logger } from "./logger";

const DOWNLOADS_DIR = process.env.DOWNLOADS_DIR || "/home/runner/workspace/downloads";

if (!fs.existsSync(DOWNLOADS_DIR)) {
  fs.mkdirSync(DOWNLOADS_DIR, { recursive: true });
}

const activeJobs = new Set<number>();

export async function startDownload(jobId: number): Promise<void> {
  if (activeJobs.has(jobId)) return;
  activeJobs.add(jobId);

  const [job] = await db.select().from(downloadJobsTable).where(eq(downloadJobsTable.id, jobId));
  if (!job) {
    activeJobs.delete(jobId);
    return;
  }

  await db.update(downloadJobsTable)
    .set({ status: "downloading", progress: 0 })
    .where(eq(downloadJobsTable.id, jobId));

  const query = job.query;
  const searchQuery = isUrl(query) ? query : `ytsearch1:${query}`;
  const outputTemplate = path.join(DOWNLOADS_DIR, `%(id)s.%(ext)s`);

  logger.info({ jobId, query }, "Starting download");

  const args = [
    "--no-playlist",
    "--extract-audio",
    "--audio-format", "mp3",
    "--audio-quality", "0",
    "--embed-thumbnail",
    "--add-metadata",
    "--write-thumbnail",
    "--output", outputTemplate,
    "--print-json",
    "--no-warnings",
    searchQuery,
  ];

  const proc = spawn("yt-dlp", args, { env: { ...process.env, PYTHONUNBUFFERED: "1" } });

  let jsonOutput = "";
  let stderr = "";

  proc.stdout.on("data", (chunk: Buffer) => {
    jsonOutput += chunk.toString();
  });

  proc.stderr.on("data", (chunk: Buffer) => {
    const line = chunk.toString();
    stderr += line;
    const match = line.match(/\[download\]\s+(\d+\.?\d*)%/);
    if (match) {
      const progress = Math.round(parseFloat(match[1]));
      db.update(downloadJobsTable)
        .set({ progress })
        .where(eq(downloadJobsTable.id, jobId))
        .catch(() => {});
    }
  });

  proc.on("close", async (code) => {
    activeJobs.delete(jobId);

    if (code !== 0) {
      logger.error({ jobId, code, stderr }, "Download failed");
      await db.update(downloadJobsTable)
        .set({ status: "failed", error: "Download failed. Song may not be available on YouTube." })
        .where(eq(downloadJobsTable.id, jobId));
      return;
    }

    try {
      const jsonLine = jsonOutput.trim().split("\n").find(l => {
        try { JSON.parse(l); return true; } catch { return false; }
      });

      if (!jsonLine) {
        await db.update(downloadJobsTable)
          .set({ status: "failed", error: "Could not parse download info" })
          .where(eq(downloadJobsTable.id, jobId));
        return;
      }

      const info = JSON.parse(jsonLine);
      const videoId = info.id;
      const title = info.title || info.fulltitle || query;
      const artist = info.artist || info.uploader || info.channel || "Unknown Artist";
      const album = info.album || null;
      const duration = info.duration ? Math.round(info.duration) : null;
      const thumbnailUrl = info.thumbnail || null;

      const mp3File = path.join(DOWNLOADS_DIR, `${videoId}.mp3`);

      if (!fs.existsSync(mp3File)) {
        await db.update(downloadJobsTable)
          .set({ status: "failed", error: "MP3 file not found after download" })
          .where(eq(downloadJobsTable.id, jobId));
        return;
      }

      const stat = fs.statSync(mp3File);

      const [song] = await db.insert(songsTable).values({
        title,
        artist,
        album,
        duration,
        filePath: mp3File,
        thumbnailUrl,
        fileSize: stat.size,
      }).returning();

      await db.update(downloadJobsTable)
        .set({
          status: "done",
          progress: 100,
          songId: song.id,
          title,
          artist,
          thumbnailUrl,
        })
        .where(eq(downloadJobsTable.id, jobId));

      logger.info({ jobId, songId: song.id, title }, "Download complete");
    } catch (err) {
      logger.error({ err, jobId }, "Failed to process downloaded file");
      await db.update(downloadJobsTable)
        .set({ status: "failed", error: "Failed to process downloaded file" })
        .where(eq(downloadJobsTable.id, jobId));
    }
  });
}

function isUrl(str: string): boolean {
  return str.startsWith("http://") || str.startsWith("https://") || str.startsWith("www.");
}

export async function processQueue(): Promise<void> {
  const pending = await db.select().from(downloadJobsTable)
    .where(eq(downloadJobsTable.status, "pending"))
    .limit(3);

  for (const job of pending) {
    if (!activeJobs.has(job.id)) {
      startDownload(job.id).catch(err => {
        logger.error({ err, jobId: job.id }, "Error in download job");
      });
    }
  }
}
